package com.me.ws;

import javax.jws.WebService;

@WebService(endpointInterface = "com.me.ws.primeNumberService")
public class primeNumber{
	
	public static boolean isPrime (int number){
		if (number < 1){
			return false;
		}
		for (int i=2; i<number ; i++){
			if (number % i == 0){
				return false;
			}
		}
		return true;
	}
}