package com.me.ws;

import java.net.URL;
import java.util.Scanner;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

public class primeNumberClient {

	public static void main(String[] args) throws Exception{
		URL url = new URL("http://127.0.0.1:3000/myself?wsdl");
		
		QName qname = new QName("http://ws.me.com/","primeNumberService");
		
		Service service = Service.create(url, qname);
		
		primeNumberService endPoint = service.getPort(primeNumberService.class);
		
		Scanner scInput = new Scanner(System.in);
		
		boolean result = true;
		
		System.out.println("Enter number: ");
		int num = Integer.parseInt(scInput.nextLine());
		result = endPoint.isPrime(num);
		System.out.println(result);
		scInput.close();
	}
}